﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Falcons.Code
{
    public class CheckoutProduct
    {
        public int ProductDetailID { get; set; }
        public int quantity { get; set; }
    }
}
