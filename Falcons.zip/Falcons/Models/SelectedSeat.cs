﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Falcons.Models
{
    public class SelectedSeat
    {
        public String SeatID { get; set; }
        public Decimal SeatPrice { get; set; }
    }
}
